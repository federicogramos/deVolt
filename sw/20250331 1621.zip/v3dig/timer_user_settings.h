// timerInt_aliases.h
////////////////////////////////////////////////////////////////////////////////
#ifndef __TIMER_USER_SETTINGS_H
#define __TIMER_USER_SETTINGS_H

// ALIAS
typedef short long type_timerSize;

#endif//__TIMER_INT_ALIASES_H