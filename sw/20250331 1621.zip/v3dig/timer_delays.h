// timerInt_delays.h
////////////////////////////////////////////////////////////////////////////////
#ifndef __TIMER_DELAYS_H
#define __TIMER_DELAYS_H

// DEFINICION DE TIEMPOS POR PARTE DEL USUARIO
type_timerSize timerDelayConstant[CANT_TIMERS]={12,12,150,18,250,18,2,1,6,2,12,8,10};
#endif//__TIMER_DELAYS_H,