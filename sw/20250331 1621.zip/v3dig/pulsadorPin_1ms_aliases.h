// pulsadorPin_aliases.h

#ifndef __PULSADOR_PIN_ALIASES_H
#define __PULSADOR_PIN_ALIASES_H

// ALIAS
enum e_pulsadorPinAlias {UP_FN,DWN_FN,UP_FP,DWN_FP,PULS_PIN_CANT};

#endif//__PULSADOR_PIN_ALIASES_H
